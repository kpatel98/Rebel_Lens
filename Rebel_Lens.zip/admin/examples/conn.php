<?php 

// $conn = mysqli_connect("localhost","root","", "rebellens");
// if ($conn->connect_error) 
// 	{
//     die("Connection failed: " . $conn->connect_error);
// 	} 


$conn = mysqli_connect("localhost","epiz_26152261","4sqQiV8MFdCp8
", "epiz_26152261_rebellens");
if ($conn->connect_error) 
	{
    die("Connection failed: " . $conn->connect_error);
	} 


	
 ?>