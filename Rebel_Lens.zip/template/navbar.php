<aside id="fh5co-aside" role="complementary" class="border js-fullheight">

			<h1 id="fh5co-logo"><a href="index.php"><img src="images/logo-colored.png" alt="Rebel Lens Photography" height="200px"></a></h1>
			<nav id="fh5co-main-menu" role="navigation">
				<ul>
					<li class="fh5co-active"><a href="index.php">Home</a></li>
					<li><a href="portfolio.php">Photos</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="contact.php">Contact</a></li>
				</ul>
			</nav>

			<div class="fh5co-footer">

				<p><small>&copy; 2020 Rebel Lens Photography. All Rights Reserved.</span> <span>Designed by <a onclick="loginauth()">#K patel</a>
				</span> <span>Photography: <a href="#" target="_blank">#Nik patel</a></span></small></p>
				<ul>
					<li><a href="#"><i class="icon-facebook"></i></a></li>
					<li><a href="#"><i class="icon-twitter"></i></a></li>
					<li><a href="#"><i class="icon-instagram"></i></a></li>
					<li><a href="#"><i class="icon-linkedin"></i></a></li>
				</ul>
			</div>

		</aside>
<script>
function loginauth() {
  var pass = prompt("Please enter your Password:");
  if (pass == "Rebel Lens") {
    location.href = 'admin/examples/dashboard.html';
  } else {
   location.href = '#';
  }
 
}
</script>