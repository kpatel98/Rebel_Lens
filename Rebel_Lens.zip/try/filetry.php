
<?php

$imagedata = getimagesize('imgupload/1593609770.jpeg');

print "Image width  is: " . $imagedata[0];
print "Image height is: " . $imagedata[1];

?>